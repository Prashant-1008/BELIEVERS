import { Routes, Route } from "react-router-dom";
import './App.css';
import LandingPage from './pages/LandingPage';
import Hello from "./pages/login";
import MasterPage from "./pages/masterPage";
import SocietHome from "./organization/societHome";
import Events from "./organization/events";
import Registration from "./organization/registretion";
import Attendence from "./organization/attendence";
import Certificate from "./organization/certificate";
import UserHome from "./user/userHome";
import UserEvent from "./user/userEvent";
import Usercertificate from "./user/usercertificate";
import UserAttendence from "./user/userAttendence";
import UserRegistration from "./user/userRegistration";
function App() {
  return (
   <>
   <Routes>
    <Route path= "/" element={<LandingPage/>}/>
    <Route path= "/helo" element={<Hello/>}/>
    <Route path= "/admin" element={<MasterPage/>}/>
    <Route path= "/s-home" element={<SocietHome/>}/>
    <Route path= "/s-events" element={<Events/>}/>
    <Route path= "/s-registration" element={<Registration/>}/>
    <Route path= "/s-attendence" element={<Attendence/>}/>
    <Route path= "/s-certificate" element={<Certificate/>}/>
    <Route path= "/u-home" element={<UserHome/>}/>
    <Route path= "/u-event" element={<UserEvent/>}/>
    <Route path= "/u-certificate" element={<Usercertificate/>}/>
    <Route path= "/u-attendence" element={<UserAttendence/>}/>
    <Route path= "/u-registration" element={<UserRegistration/>}/>
   </Routes>
   </>
  );
}

export default App;
