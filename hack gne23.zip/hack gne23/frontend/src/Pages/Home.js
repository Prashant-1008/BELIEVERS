import React from 'react'
import './home.css'
//import Layout from "../Layout/Layout"
import header from "../imeges/header1.png"
const Home = () => {
  return (
    <>
   <img src={header} alt="Logo"  className='hero-img'/> 

   <div className='main-sec mt-5'>
<div className='l-sec'>
  <h3 className='sec-h3'>ANNOUNCEMENTS</h3>

</div>
<div className='r-sec  '>

</div>

   </div>

    </>
  )
}

export default Home;