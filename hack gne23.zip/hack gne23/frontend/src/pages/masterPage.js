import React, { useState } from 'react';

import Layout from '../Layout/Layout';
import '../pages/tab.css'
import '../pages/card.css'

const MasterPage = () => {

    const [isSocietyListVisible, setIsSocietyListVisible] = useState(true);
    const [isCreateSocietyVisible, setIsCreateSocietyVisible] = useState(false);
  
    const showSocietyList = () => {
      setIsSocietyListVisible(true);
      setIsCreateSocietyVisible(false);
    };
  
    const showCreateSociety = () => {
      setIsSocietyListVisible(false);
      setIsCreateSocietyVisible(true);
    };
  return (
    <Layout title={"Master Page"}>
    
    <div className="container-fluid">
      <div className="row tab-style">
        <div className="col-1 p-0"></div>
        
        <div className={`col-5 p-0 ${isSocietyListVisible ? 'active-tab' : ''}`} onClick={showSocietyList}>
          <div className="tab-list">SOCIETY LIST</div>
        </div>
        <div className={`col-5 justify-content-center p-0 ${isCreateSocietyVisible ? 'active-tab' : ''}`} onClick={showCreateSociety}>
          <div className="tab-list">CREATE SOCIETY</div>
          </div>
        <div className="col-1 p-0"></div>
      </div>

      {isSocietyListVisible && (<>
      
      
       <div className="container card-custom-container">
       <div className="row">
         <div className="col-2 custom-logo">
           <i className="fas fa-circle fa-10x" />
         </div>
         <div className="col-8">
           <div className="row">
             <div className="col-12 custom-text">
               Event Name: <span className="custom-data">CSI</span>
             </div>
           </div>
           <div className="row">
             <div className="col-6 custom-text">
               Society Head: <span className="custom-data">Ayush singh</span>
             </div>
             <div className="col-6 custom-text">
               Society Convener: <span className="custom-data">Tushar singh</span>
             </div>
           </div>
           <div className="row">
             <div className="col-6 custom-text">
               Contact: <span className="custom-data">7482737677</span>
             </div>
             <div className="col-6  custom-text">
               Email: <span className="custom-data">ayush123@gmail.com</span>
             </div>
           </div>
         </div>
         <div className="col-2 custom-buttons">
           <button className="btn custom-button">
             <i className="fas fa-pencil-alt" style={{color: 'white', fontSize: '2rem'}} />
           </button>
           <button className="btn custom-button">
             <i className="fas fa-trash" style={{color: 'white', fontSize: '2rem'}} />
           </button>
         </div>
       </div>
     </div>
     
{/* // card2 */}

<div className="container card-custom-container mt-5">
       <div className="row">
         <div className="col-2 custom-logo">
           <i className="fas fa-circle fa-10x" />
         </div>
         <div className="col-8">
           <div className="row">
             <div className="col-12 custom-text">
               Event Name: <span className="custom-data">ISTE</span>
             </div>
           </div>
           <div className="row">
             <div className="col-6 custom-text">
               Society Head: <span className="custom-data">Ayush singh</span>
             </div>
             <div className="col-6 custom-text">
               Society Convener: <span className="custom-data">Tushar Kumar</span>
             </div>
           </div>
           <div className="row">
             <div className="col-6 custom-text">
               Contact: <span className="custom-data">7482737677</span>
             </div>
             <div className="col-6  custom-text">
               Email: <span className="custom-data">ayush123@gmail.com</span>
             </div>
           </div>
         </div>
         <div className="col-2 custom-buttons">
           <button className="btn custom-button">
             <i className="fas fa-pencil-alt" style={{color: 'white', fontSize: '2rem'}} />
           </button>
           <button className="btn custom-button">
             <i className="fas fa-trash" style={{color: 'white', fontSize: '2rem'}} />
           </button>
         </div>
       </div>
     </div>
     </>
      )}

      {isCreateSocietyVisible && (
           <div className="container-fluid" style={{ display: 'flex', justifyContent: 'space-around' }}>
           <div className="container-md-sm form-cont-style">
             {/* Row 1: Heading */}
             <div className="row">
               <div className="col-12 form-heading">CREATE SOCIETY</div>
             </div>
     
             {/* Row 2: Society Name and Society Head (In One Line) */}
             <div className="row form-row-m form-row">
               <div className="col-md-6">
                 <label className="form-label" htmlFor="societyName">Society Name</label>
                 <input type="text" className="form-control input-box" id="societyName" placeholder="Enter Society Name" />
               </div>
               <div className="col-md-6">
                 <label className="form-label" htmlFor="societyHead">Society Head</label>
                 <input type="text" className="form-control input-box" id="societyHead" placeholder="Society Head Name" />
               </div>
             </div>
     
             {/* Row 3: Society Convener and Contact (In One Line) */}
             <div className="row form-row-m form-row">
               <div className="col-md-6">
                 <label className="form-label" htmlFor="societyConvener">Society Convener</label>
                 <input type="text" className="form-control input-box" id="societyConvener" placeholder="Society Convener Name" />
               </div>
               <div className="col-md-6">
                 <label className="form-label" htmlFor="contact">Contact</label>
                 <input type="text" className="form-control input-box" id="contact" placeholder="Enter Number" />
               </div>
             </div>
     
             {/* Row 4: Email and Logo (In One Line) */}
             <div className="row form-row-m form-row">
               <div className="col-md-6">
                 <label className="form-label" htmlFor="email">Email</label>
                 <input type="text" className="form-control input-box" id="email" placeholder="Enter Email" />
               </div>
               <div className="col-md-6">
                 <label className="form-label" htmlFor="pass">Password</label>
                 <input type="password" className="form-control input-box" id="pass" placeholder="Enter Password" />
               </div>
             </div>
     
             {/* Row 4.2: Email and Logo (In One Line) */}
             <div className="row form-row-m form-row">
               <div className="col-md-6">
                 <label className="form-label" htmlFor="cpass">Confirm Password</label>
                 <input type="password" className="form-control input-box" id="cpass" placeholder="Confirm password" />
               </div>
             </div>
     
             {/* Row 5: Society Banner */}
             <div className="row form-row-m form-row">
               <div className="col-md-6">
                 <label className="form-label" htmlFor="logo">Logo</label>
                 <input type="file" className="form-control-file chooseinput-box" id="logo" placeholder="Choose Logo" />
               </div>
               <div className="col-md-6">
                 <label className="form-label" htmlFor="banner">Society Banner</label>
                 <input type="file" className="form-control-file chooseinput-box" id="banner" placeholder="Choose Banner" />
               </div>
             </div>
     
             {/* Row 7: Create and Reset Buttons */}
             <div className="row form-row-m">
               <div className="col-2"></div>
               <div className="col-md-4 btn-container">
                 <button className="btn btn-primary" style={{ backgroundColor: '#CA221B' }}>CREATE SOCIETY</button>
               </div>
               <div className="col-md-4 btn-container">
                 <button className="btn btn-secondary" style={{ backgroundColor: '#CA221B' }}>RESET</button>
               </div>
               <div className="col-2"></div>
             </div>
           </div>
         </div>
     
      )}
    </div>
    

    </Layout>
  )
}

export default MasterPage;