import React, { useState } from 'react';
import Footer from '../Layout/footer';
import { Link } from 'react-router-dom';
import axios from "axios";
import { useNavigate,useLocation } from 'react-router-dom';
import {toast} from "react-hot-toast";
import { useAuth } from '../context/auth';
const LandingPage = () => {

//   const [email,setEmail] = useState("");
//   const [password,setPassword] = useState("");
//   const [auth,setAuth] = useAuth();
//   const navigate = useNavigate();
//   const location = useLocation();
//   const handleSubmit = async (e) =>{
//       e.preventDefault();
//       try {
//           const res = await axios.post(`${process.env.REACT_APP_API}/api/v1/auth/login`,
//           {email,password,}
//           );
//           if (res && res.data.success){
//               toast.success(res.data && res.data.message);
//               setAuth({
//                   ...auth,
//                   user: res.data.user,
//                   token: res.data.token, 
//               });
// // localStorage.setItem('auth', JSON.stringify(res.data));
// setTimeout(()=> {
// navigate( location.state || "/home")
// }, 2000);
//           }else{
//               toast.error(res.data.message)
//           }
//       } catch (error) {
//           console.log(error)
//           toast.error("Enter Right Email and Password");

          
//       }
//   };

  const [isSocietyListVisible, setIsSocietyListVisible] = useState(true);
  const [isCreateSocietyVisible, setIsCreateSocietyVisible] = useState(false);

  const showSocietyList = () => {
    setIsSocietyListVisible(true);
    setIsCreateSocietyVisible(false);
  };

  const showCreateSociety = () => {
    setIsSocietyListVisible(false);
    setIsCreateSocietyVisible(true);
  };
  
  return (
   <>
  
   <div className='container-fluide'>
   <img  src="logo.png" className="img-fluid header" alt="logo" />
<div className='landing mt-5'>
<div className='landing-l '>
<h3 className='col-12 form-heading'>ANNOUNCEMENTS</h3>
<div >
<p className='landing-p'>
    CSI Event <sup><span class="badge bg-danger">New</span></sup>
   
</p>
<hr/>
<p className='landing-p'>
    ISTE Event <sup><span class="badge bg-danger">New</span></sup>
   
</p>
<hr/>
<p className='landing-p'>
     Event <sup><span class="badge bg-danger">New</span></sup>
   
</p>
<hr/>
</div>

</div>
<div className='landing-r'>

<div className='container-fluid tab-btn'>
  <div className='row'>
    <div className={ `col-6 std-btn ${isSocietyListVisible ? 'active-tab' : ''}`} onClick={showSocietyList}>STUDENT</div>
    <div className={`col-6 soc-btn justify-content-center p-0 ${isCreateSocietyVisible ? 'active-tab' : ''}`} onClick={showCreateSociety}>SOCIETY</div>
  </div>

  {/* FORM-START */}
 {isSocietyListVisible && (

  <div className="container " style={{marginTop:'4rem'}} >
    {/* Row 4: Email and Logo (In One Line) */}
    <div className="row ">
      <div className="col " style={{display:'flex' , alignItems:'center' , justifyContent:'space-between'}}>
        <label className="form-label" htmlFor="email">Email</label>
        <input type="email" className="form-control input-box" id="email" placeholder="Enter Email" />
      </div>
    </div>
    {/* Row 4: Email and Logo (In One Line) */}
    <div className="row ">
      <div className="col" style={{display:'flex', alignItems:'center' , justifyContent:'space-between'}}>
        <label className="form-label" htmlFor="pass">Password</label>
        <input type="password" className="form-control input-box" id="pass" placeholder="Enter Password"  />
      </div>
    </div>
    {/* Row 7: Create and Reset Buttons */}
    <div className="row">
      <div className="col-1" />
      <div className="col-md-4 btn-container">
        <Link to="/u-home"><button className="btn btn-primary button" style={{backgroundColor: '#CA221B', width:'12rem'}}>LOGIN</button></Link>
      </div>
      <div className="col-md-4 btn-container">
        <button className="btn btn-secondary button" style={{backgroundColor: '#CA221B' , width:'12rem' , marginLeft:'2rem'}}>RESET</button>
      </div>
      <div className="col-1" />
    </div>
    <div className='row' style={{marginTop:'6rem', fontSize:'1.7rem'}}>
      <div className='col-6' style={{textAlign:'start'}}>
       <Link to="/u-registration"> <b><u>Sign Up</u></b></Link>
      </div>
      <div className='col-6'style={{textAlign:'end'}}> 
        <b><u>Forget Password</u></b>
      </div>
    </div>
  
  &nbsp;&nbsp;&nbsp;&nbsp;</div>
  
 )}


</div>

{isCreateSocietyVisible && (
  
  <div className="container " style={{marginTop:'4rem'}} >
    {/* Row 4: Email and Logo (In One Line) */}
    <div className="row ">
      <div className="col " style={{display:'flex' , alignItems:'center' , justifyContent:'space-between'}}>
        <label className="form-label" htmlFor="email">Email</label>
        <input type="email" className="form-control input-box" id="email" placeholder="Enter Email"  />
      </div>
    </div>
    {/* Row 4: Email and Logo (In One Line) */}
    <div className="row ">
      <div className="col" style={{display:'flex', alignItems:'center' , justifyContent:'space-between'}}>
        <label className="form-label" htmlFor="pass">Password</label>
        <input type="password" className="form-control input-box" id="pass" placeholder="Enter Password" />
      </div>
    </div>
    {/* Row 7: Create and Reset Buttons */}
    <div className="row">
      <div className="col-1" />
      <div className="col-md-4 btn-container">
        <Link to="/s-home"><button className="btn btn-primary button" style={{backgroundColor: '#CA221B', width:'12rem'}}>LOGIN</button></Link>
      </div>
      <div className="col-md-4 btn-container">
        <button className="btn btn-secondary button" style={{backgroundColor: '#CA221B' , width:'12rem' , marginLeft:'2rem'}}>RESET</button>
      </div>
      <div className="col-1" />
    </div>
    <div className='row' style={{marginTop:'6rem', fontSize:'1.7rem'}}>
     
      <div className='col-6'style={{textAlign:'start'}}> 
        <b><u>Forget Password</u></b>
      </div>
    </div>
  
  &nbsp;&nbsp;&nbsp;&nbsp;</div>
  

)}

</div>

</div>
{/* CERTIFICATE VERIFICATION */}
<div className="container-fluid mt-5" style={{display: 'flex', justifyContent: 'space-around'}}>
  <div className="container-md-sm form-cont-style">
    {/* Row 1: Heading */}
    <div className="row ">
      <div className="col-12 form-heading">
        CERTIFICATE VARIFICATION
      </div>
    </div>
    {/* Row 2: ENTRY FIELD */}
    <div className="row form-row-m form-row">
      <div className="col-md-6">
        <label className="form-label" htmlFor="SelectSociety">Select Society</label>
        <div className="dropdown">
         
        <select >

<option className="form-control input-box"  value="CSI">CSI</option>

<option className="form-control input-box" value="DSC">DSC</option>

<option className="form-control input-box" value="ISTE">ISTE</option>


</select>
        </div>
      </div>
      <div className="col-md-6">
        <label className="form-label" htmlFor="CertificateNumber">Certificate No.</label>
        <input type="text" className="form-control input-box" id="CertificateNumber" placeholder="Enter Certificate No." />
      </div>
    </div>
    {/* Row 3: ENTRY FIELD */}
    <div className="row form-row-m form-row">
      <div className="col-md-6">
        <label className="form-label" htmlFor="urn">Urn</label>
        <input type="number" className="form-control input-box" id="societyConvener" placeholder="Enter Urn" />
      </div>
    </div>           
    {/* Row 7: Create and Reset Buttons */}
    <div className="row form-row-m">
      <div className="col-2" />
      <div className="col-md-4 btn-container">
        <button className="btn btn-primary button" style={{backgroundColor: '#CA221B'}}> VERIFY</button>
      </div>
      <div className="col-md-4 btn-container">
        <button className="btn btn-secondary button" style={{backgroundColor: '#CA221B'}}>RESET</button>
      </div>
      <div className="col-2" />
    </div>
  </div>
</div>

   {/* <div className="footer mt-4">All Right Reserved © GNDEC-2023</div> */}
<div>
<Footer/>

</div>
   </div>

   </>
  )
}

export default LandingPage;