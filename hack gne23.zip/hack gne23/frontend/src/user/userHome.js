import React from 'react'
import Layoutu from '../Layout/Layoutu';
import '../organization/societybanner.css'
const UserHome = () => {
  return (
   <Layoutu title={"User HomePage"}>

<div  className='landing mt-5'>
    <div className='landing-r mr'>
    <h3 className='col-12 form-heading'>USER DETAILS</h3>
    <div className='cir-m'>
           <div className='cir'>
            <img src='https://media.istockphoto.com/id/1454390900/photo/young-asian-man-graphic-designer-working-in-his-studio-office.webp?b=1&s=612x612&w=0&k=20&c=PB4Fj-BM33NY5qKwBXOuVs5hNIetNagmMoHCrbYkXBM='alt='logo 'className='cir-img'/>
            </div> 

    </div>
    <hr/>
<p className='cir-p'>Name :<span>Computer Science of India</span></p>
<hr/>
<p className='cir-p'>Urn :<span>2104470</span>  </p>
<hr/>
<p className='cir-p'>Crn :<span>2121014</span>  </p>
<hr/>
<p className='cir-p'>Branch :<span>IT</span>
</p>
<hr/>
<p className='cir-p'>Year :<span>3<sup>rd</sup></span> </p>
<hr/>
<p className='cir-p'>Mobile :<span>988546553</span>  </p>
<hr/>
<p className='cir-p'>Email :<span> ANSHICH@123.GMAIL.COM</span></p>
    </div>
    <div className='landing-ll '>
    <h3 className='col-12 form-heading'>REGISTERED EVENTS</h3>
    <h3 className='cir-h '>CSI EVENT <sup><span class="badge bg-danger">New</span></sup></h3>
    <hr/>
    <h3 className='cir-h '>Data Science Club<sup><span class="badge bg-danger">New</span></sup></h3>
    <hr/>
    <h3 className='cir-h '>CSI EVENT <sup><span class="badge bg-danger">New</span></sup></h3>
    <hr/>
    <h3 className='cir-h '>Data Science Club<sup><span class="badge bg-danger">New</span></sup></h3>
    <hr/>
    <h3 className='cir-h '>CSI EVENT<sup><span class="badge bg-danger">New</span></sup></h3>
    <hr/>
    <h3 className='cir-h '>Data Science Club<sup><span class="badge bg-danger">New</span></sup></h3>
    <hr/>
    </div>
</div>
   </Layoutu>
  )
}

export default UserHome;