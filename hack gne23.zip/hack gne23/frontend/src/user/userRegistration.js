
import React,{useState} from 'react';
import axios from "axios";
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import Layout from '../Layout/Layout';
const UserRegistration = () => {
    const [name,setName] = useState("")
    const [email,setEmail] = useState("")
    const [password,setPassword] = useState("")
    const [confirmPassword, setConfirmPassword] = useState("");
    const [phoneNumber,setPhoneNumber] = useState("")
    const [branch,setBranch] = useState("")
    const [crn,setCrn] = useState("")
    const [urn,setUrn] = useState("")
    const [year,setYear] = useState("")
    const navigate = useNavigate()

    const handleSubmit = async (e) =>{
        e.preventDefault();
        try {
            const res = await axios.post(`${process.env.REACT_APP_API}/api/v1/auth/register`,
            {name,email,password,phoneNumber,branch,urn,crn,year}
            );
            if (res && res.data.success){
                toast.success(res.data.message)
                setTimeout(()=> {
                  navigate('/');
                 }, 2000);
            }else{
                toast.error(res.data.message)
            }
        } catch (error) {
            console.log(error)
            toast.error("Something went wrong");

            
        }
    };
    console.log(process.env.REACT_APP_API);

    const [showPassword, setShowPassword] = useState(false);

    const handleTogglePassword = () => {
        setShowPassword(!showPassword);
    };
  return (
    <Layout>
    <>
 {/* FORM-START */}
 

 <form onSubmit={handleSubmit}>

 
<div className="container-fluid" style={{display: 'flex', justifyContent: 'space-around'}}>
  <div className="container-md-sm form-cont-style">
    {/* Row 1: Heading */}
    <div className="row ">
      <div className="col-12 form-heading">
        STUDENT REGISTRATION FORM
      </div>
    </div>
    {/* Row 2: Society Name and Society Head (In One Line) */}
    <div className="row form-row-m form-row">
      <div className="col-md-6">
        <label className="form-label" htmlFor="studentname"> Name</label>
        <input type="text" className="form-control input-box" id="studentname" placeholder="Enter Name"
        value={name} 
        onChange={(e) => setName(e.target.value)} />
      </div>
      <div className="col-md-6">
        <label className="form-label" htmlFor="studentbrach">Branch</label>
        <input type="text" className="form-control input-box" id="studentbrach" placeholder="Enter Branch"value={branch} 
          onChange={(e) => setBranch(e.target.value)} />
      </div>
    </div>
    {/* Row 3: Society Convener and Contact (In One Line) */}
    <div className="row form-row-m form-row">
      <div className="col-md-6">
        <label className="form-label" htmlFor="crn">Crn</label>
        <input type="number" className="form-control input-box" id="crn" placeholder="Enter Crn"value={crn} 
          onChange={(e) => setCrn(e.target.value)} />
      </div>
      <div className="col-md-6">
        <label className="form-label" htmlFor="urn">Urn</label>
        <input type="number" className="form-control input-box" id="urn" placeholder="Enter Urn"value={urn} 
          onChange={(e) => setUrn(e.target.value)} />
      </div>
    </div>
    {/* Row 4: Email and Logo (In One Line) */}
    <div className="row form-row-m form-row">
      <div className="col-md-6">
        <label className="form-label" htmlFor="year">Year</label>
        <input type="number" className="form-control input-box" id="year" placeholder="Enter Year[like: D3]"value={year} 
          onChange={(e) => setYear(e.target.value)} />
      </div>
      <div className="col-md-6">
        <label className="form-label" htmlFor="mobile">Mobile</label>
        <input type="number" className="form-control input-box" id="mobile" placeholder="Enter Mobile No." value={phoneNumber} 
          onChange={(e) => setPhoneNumber(e.target.value)}/>
      </div>
    </div>
    {/* Row 4.2: Email and Logo (In One Line) */}
    <div className="row form-row-m form-row">
      <div className="col-md-6">
        <label className="form-label" htmlFor="email">Email</label>
        <input type="email" className="form-control input-box " id="email" placeholder="Enter Password" value={email} 
          onChange={(e) => setEmail(e.target.value)}/>
      </div>
      <div className="col-md-6">
        <label className="form-label" htmlFor="photo">photo</label>
        <input type="file" className="form-control-file chooseinput-box " id="photo" placeholder="Choose photo" />
      </div>
    </div>
    {/* Row 5: Society Banner */}
    <div className="row form-row-m form-row">
      <div className="col-md-6">
        <label className="form-label" htmlFor="pass">Password</label>
        <input type="password" className="form-control input-box " id="pass" placeholder="Enter Password" value={password} 
          onChange={(e) => setPassword(e.target.value)}/>
      </div>
      <div className="col-md-6">
        <label className="form-label" htmlFor="cpass">Confirm Password</label>
        <input type="password" className="form-control  input-box" id="cpass" placeholder="Conform Password" />
      </div>
    </div>
    {/* Row 7: Create and Reset Buttons */}
    <div className="row form-row-m">
      <div className="col-2" />
      <div className="col-md-4 btn-container">
        <button className="btn btn-primary button" style={{backgroundColor: '#CA221B'}}>REGISTER</button>
      </div>
      <div className="col-md-4 btn-container">
        <button type="reset" className="btn btn-secondary button" style={{backgroundColor: '#CA221B'}}>RESET</button>
      </div>
      <div className="col-2" />
    </div>
  </div>
</div>

</form>
    </>
    </Layout>
  )
}

export default UserRegistration;