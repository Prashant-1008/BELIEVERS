import React from 'react'
import Layoutu from '../Layout/Layoutu';

const Usercertificate = () => {
  return (
   <Layoutu title={"Download Certificate"}>
<div className="container card-custom-container mt-5" style={{height: '16rem'}}>
  <div className="row">
    <div className="col-2 custom-logo">
      <i className="fas fa-circle fa-10x" />
    </div>
    <div className="col-7">
      <div className="row">
        <div className="col-12 custom-text">
          Event Name: <span className="custom-data">hacking</span>
        </div>
      </div>
      <div className="row">
        <div className="col-12 custom-text">
          Society Name: <span className="custom-data">csi</span>
        </div>
      </div>
      <div className="row">
        <div className="col-12 custom-text">
          Contact: <span className="custom-data">9779945798</span>
        </div>
      </div>
    </div>
    <div className="col-3 " style={{display: 'flex', justifyContent: 'center', alignItems: 'center'}}>
      <div className="row">
        <div className="col-12  ">
          <button className="btn btn-secondary button" style={{backgroundColor: '#CA221B', marginTop: 'rem', marginBottom: '1rem', width: '18rem'}}>DOWNLOAD</button>
        </div>
      </div>
    </div>
  </div>
</div>


   </Layoutu>
  )
}

export default Usercertificate;