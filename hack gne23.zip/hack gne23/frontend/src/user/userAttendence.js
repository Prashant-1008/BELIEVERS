import React from 'react'
import Layoutu from '../Layout/Layoutu';

const UserAttendence = () => {
  return (
    <Layoutu title={"Attendence"}>
<div className="row mt-5">
  <div className="col-7 " style={{color: 'black', fontSize: '2rem', fontWeight: 400, display: 'flex', alignItems: 'center', paddingLeft: '7rem'}}>
    To Mark Attendence Click on The Button
  </div>
  <div className="col-5  " style={{display: 'flex', justifyContent: 'center', alignItems: 'center'}}>
    <button className="btn btn-secondary button" style={{backgroundColor: '#CA221B', marginTop: 'rem', marginBottom: '1rem', width: '18rem'}}>Mark Attendence</button>
  </div>
</div>

    </Layoutu>
  )
}

export default UserAttendence;