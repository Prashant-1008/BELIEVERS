import React from 'react'
import Layoutu from '../Layout/Layoutu';

const UserEvent = () => {
  return (
    <Layoutu title={"Events"}>
<div className="container card-custom-container mt-5" style={{height: '18rem'}}>
  <div className="row">
    <div className="col-2 custom-logo">
      <i className="fas fa-circle fa-10x" />
    </div>
    <div className="col-8">
      <div className="row">
      <div class="col-6 custom-text">
                        Event Name: <span class="custom-data">Hacking</span>
                    </div>
                    <div class="col-6 custom-text">
                        Society Name: <span class="custom-data">csi</span>
                    </div>
      </div>
      <div className="row">
        <div className="col-6 custom-text">
          Event Mode: <span className="custom-data">online</span>
        </div>
        <div className="col-6 custom-text">
          Event Vanue: <span className="custom-data">Auditorium</span>
        </div>
      </div>
      <div className="row">
        <div className="col-6 custom-text">
          Event Date: <span className="custom-data">21/02/2023</span>
        </div>
        <div className="col-6 custom-text">
          Event Start Time: <span className="custom-data">02:00:00</span>
        </div>
      </div>
      <div className="row">
        <div className="col-6 custom-text">
          Deadline Date: <span className="custom-data">22/02/2023</span>
        </div>
        <div className="col-6 custom-text">
          Deadline Time: <span className="custom-data">12:00:00</span>
        </div>
      </div>
    </div>
    <div className="col-2 ">
      <div className="row">
        <div className="col-12  ">
          <button className="btn btn-secondary button" style={{backgroundColor: '#CA221B', marginTop: '1rem', marginBottom: '1rem', width: '14rem'}}>KNOW MORE</button>
        </div>
      </div>
      <div className="row">
        <div className="col-12  ">
          <button className="btn btn-secondary button" style={{backgroundColor: '#CA221B', marginTop: 5, marginBottom: '1rem', width: '14rem'}}>REGISTER</button>
        </div>
      </div>
    </div>
  </div>
</div>
{/* card2 */}
<div className="container card-custom-container mt-5" style={{height: '18rem'}}>
  <div className="row">
    <div className="col-2 custom-logo">
      <i className="fas fa-circle fa-10x" />
    </div>
    <div className="col-8">
      <div className="row">
      <div class="col-6 custom-text">
                        Event Name: <span class="custom-data">Hacking</span>
                    </div>
                    <div class="col-6 custom-text">
                        Society Name: <span class="custom-data">csi</span>
                    </div>
      </div>
      <div className="row">
        <div className="col-6 custom-text">
          Event Mode: <span className="custom-data">offline</span>
        </div>
        <div className="col-6 custom-text">
          Event Vanue: <span className="custom-data">Auditorium</span>
        </div>
      </div>
      <div className="row">
        <div className="col-6 custom-text">
          Event Date: <span className="custom-data">12/12/2023</span>
        </div>
        <div className="col-6 custom-text">
          Event Start Time: <span className="custom-data">12:00:00</span>
        </div>
      </div>
      <div className="row">
        <div className="col-6 custom-text">
          Deadline Date: <span className="custom-data">12/12/2023</span>
        </div>
        <div className="col-6 custom-text">
          Deadline Time: <span className="custom-data">12:00:00</span>
        </div>
      </div>
    </div>
    <div className="col-2 ">
      <div className="row">
        <div className="col-12  ">
          <button className="btn btn-secondary button" style={{backgroundColor: '#CA221B', marginTop: '1rem', marginBottom: '1rem', width: '14rem'}}>KNOW MORE</button>
        </div>
      </div>
      <div className="row">
        <div className="col-12  ">
          <button className="btn btn-secondary button" style={{backgroundColor: '#CA221B', marginTop: 5, marginBottom: '1rem', width: '14rem'}}>REGISTER</button>
        </div>
      </div>
    </div>
  </div>
</div>
    </Layoutu>
  )
}

export default UserEvent;