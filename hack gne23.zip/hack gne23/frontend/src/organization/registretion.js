import React from 'react'
import Layoutso from '../Layout/Layoutso';

const Registration = () => {
  return (
    <Layoutso title={"Registration"}>
{/* CREATE-CARD */}
<div class="container registration">
        Total Registation count : <span>67</span>
    </div>
<div className="container card-custom-container mt-5 mb-4" style={{height: '18rem'}}>
  <div className="row">
    <div className="col-2 custom-logo">
      <i className="fas fa-circle fa-10x" />
    </div>
    <div className="col-8">
      <div className="row">
        <div className="col-12 custom-text">
          Name: <span className="custom-data">Ayush Singh</span>
        </div>
      </div>
      <div className="row">
        <div className="col-6 custom-text">
          Urn: <span className="custom-data">2104484</span>
        </div>
        <div className="col-6 custom-text">
          Crn: <span className="custom-data">2121028</span>
        </div>
      </div>
      <div className="row">
        <div className="col-6 custom-text">
          Branch: <span className="custom-data">Branch</span>
        </div>
        <div className="col-6 custom-text">
          Year: <span className="custom-data">D3</span>
        </div>
      </div>
      <div className="row">
        <div className="col-6 custom-text">
          Email: <span className="custom-data">ayush121@gmail.com</span>
        </div>
        <div className="col-6 custom-text">
          Mobile: <span className="custom-data">9779945798</span>
        </div>
      </div>
    </div>
  </div>
</div>
{/* card2 */}
{/* CREATE-CARD */}
<div className="container card-custom-container" style={{height: '18rem'}}>
  <div className="row">
    <div className="col-2 custom-logo">
      <i className="fas fa-circle fa-10x" />
    </div>
    <div className="col-8">
      <div className="row">
        <div className="col-12 custom-text">
          Name: <span className="custom-data">Ayush Singh</span>
        </div>
      </div>
      <div className="row">
        <div className="col-6 custom-text">
          Urn: <span className="custom-data">2104484</span>
        </div>
        <div className="col-6 custom-text">
          Crn: <span className="custom-data">2121028</span>
        </div>
      </div>
      <div className="row">
        <div className="col-6 custom-text">
          Branch: <span className="custom-data">Branch</span>
        </div>
        <div className="col-6 custom-text">
          Year: <span className="custom-data">D3</span>
        </div>
      </div>
      <div className="row">
        <div className="col-6 custom-text">
          Email: <span className="custom-data">ayush121@gmail.com</span>
        </div>
        <div className="col-6 custom-text">
          Mobile: <span className="custom-data">9779945798</span>
        </div>
      </div>
    </div>
  </div>
</div>



    </Layoutso>
  )
}

export default Registration;