import React from 'react'
import '../organization/societybanner.css'
import Layoutso from '../Layout/Layoutso';
import header11 from '../images/header11.png';
import header111 from '../images/banner1.jpg';
const SocietHome = () => {
  return (
   <Layoutso title={"Society HomePage"}>

<img src={header11} alt='header' className='banner'/>
<div  className='landing mt-5'>
    <div className='landing-r mr'>
    <h3 className='col-12 form-heading'>SOCIETY DETAILS</h3>
    <div className='cir-m'>
           <div className='cir'>
            <img src='https://media.istockphoto.com/id/1454390900/photo/young-asian-man-graphic-designer-working-in-his-studio-office.webp?b=1&s=612x612&w=0&k=20&c=PB4Fj-BM33NY5qKwBXOuVs5hNIetNagmMoHCrbYkXBM='alt='logo 'className='cir-img'/>
            </div> 

    </div>
    <hr/>
<p className='cir-p'>Society Name :<span>Computer Science of India</span></p>
<hr/>
<p className='cir-p'>Society Head :<span>Ayush Singh</span>
</p>
<hr/>
<p className='cir-p'>Convener :<span>Tushar Singh</span> </p>
<hr/>
<p className='cir-p'>Mobile :<span>988546553</span>  </p>
<hr/>
<p className='cir-p'>Email :<span> ANSHICH@123.GMAIL.COM</span></p>
    </div>
    <div className='landing-ll '>
    <h3 className='col-12 form-heading'>UPCOMING EVENT STATUS</h3>
    <h3 className='cir-h '>CSI EVENT <sup><span class="badge bg-danger">New</span></sup></h3>
    <hr/>
    <h3 className='cir-h '>Data Science Club<sup><span class="badge bg-danger">New</span></sup></h3>
    <hr/>
    <h3 className='cir-h '>CSI EVENT <sup><span class="badge bg-danger">New</span></sup></h3>
    <hr/>
    <h3 className='cir-h '>Data Science Club<sup><span class="badge bg-danger">New</span></sup></h3>
    <hr/>
    <h3 className='cir-h '>CSI EVENT <sup><span class="badge bg-danger">New</span></sup></h3>
    <hr/>
    <h3 className='cir-h '>Data Science Club<sup><span class="badge bg-danger">New</span></sup></h3>
    <hr/>
    </div>
</div>

   </Layoutso>
  )
}

export default SocietHome;