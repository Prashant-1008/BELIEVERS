import React from 'react'
import Layoutso from '../Layout/Layoutso';

const Attendence = () => {
  return (
   <Layoutso title={"Attendence"}>
  <div>
  {/* DROPDOWN */}
  <div className="container mt-4">
    <div className="row">
      <div className="col-1" />
      <div className="col-4">
        <p className="event-text">Choose Event</p>
      </div>
      <div className="col-6">
        <div className="dropdown">
          <button className="btn custom-dropdown dropdown-toggle" type="button" id="eventDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Choose Event
          </button>
          <div className="dropdown-menu" aria-labelledby="eventDropdown">
            <a className="dropdown-item event-item" href="#" data-value="workshop">workshop</a>
            <a className="dropdown-item event-item" href="#" data-value="competition">competition</a>
            <a className="dropdown-item event-item" href="#" data-value="expert-talk">Expert talk</a>
          </div>
        </div>
      </div>
      <div className="col-1" />
    </div>
  </div>
  {/* ACTIVATE BUTTON */}
  <div className="row mt-5">
    <div className="col-7 " style={{color: 'black', fontSize: '2rem', fontWeight: 600, display: 'flex', alignItems: 'center', paddingLeft: '7rem'}}>
      To Activate/Deactivate Click on The Button
    </div>
    <div className="col-5  " style={{display: 'flex', alignItems: 'center'}}>
      <button className="btn btn-secondary button" style={{backgroundColor: '#CA221B', marginTop: 'rem', marginBottom: '1rem', width: '18rem'}}>ACTIVATE</button>
    </div>
  </div>
  {/* SET TYPE */}
<div className="container form-cont-style" style={{width: '106rem', padding: '2rem', borderRadius: 10, margin: '2rem auto'}}>
  <div className="row">
    <div className="col-2" style={{display: 'flex', justifyContent: 'center', alignItems: 'center'}}>
      <label className="form-label" htmlFor style={{fontWeight: 700}}>Set Type</label>
    </div>
    {/* DROPDOWN */}
    <div className="col-4" style={{display: 'flex', alignItems: 'center'}}>
      <div className="row">
        <div className="col">
          <div className="dropdown">
            <button className="btn custom-dropdown dropdown-toggle" type="button" id="typeDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style={{width: '26rem', height: '3rem', border: '1px solid #CA221B', fontSize: '1.5rem', fontWeight: '4w00'}}>
              Choose Type
            </button>
            <div className="dropdown-menu" aria-labelledby="typeDropdown">
              <a className="dropdown-item type-item" href="#" data-value="Winner">Winner</a>
              <a className="dropdown-item type-item" href="#" data-value="Organizer">Organizer</a>
              <a className="dropdown-item type-item" href="#" data-value="Participant">Participant</a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div className="col-4" style={{display: 'flex', alignItems: 'center'}}>
      <input type="number" className="form-control input-box" id="txt" placeholder="Enter Urn" />
    </div>
    <div className="col-2" style={{display: 'flex', justifyContent: 'center', alignItems: 'center'}}>
      <button className="btn btn-secondary button" style={{backgroundColor: '#CA221B'}}>SET TYPE</button>
    </div>
  </div>
</div>


  {/* FORM-START */}
  <div className="container-fluid" style={{display: 'flex', justifyContent: 'space-around'}}>
  <div className="container-md-sm form-cont-style">
    {/* Row 1: Heading */}
    <div className="row ">
      <div className="col-12 form-heading addattendence">
        ATTENDENCE
      </div>
    </div>
    {/* Row 2: Society Name and Society Head (In One Line) */}
    {/*  <div class="row  form-row" style="border-bottom: 2px solid;">
          <div class="col-md-3"style="display: flex;
          align-items: center;
          justify-content: center;
          border-right: 2px solid #C5C5C5;">
              <h2>URN</h2>
          </div>
          <div class="col-md-3"style="display: flex;
          align-items: center;
          justify-content: center;
          border-right: 2px solid #C5C5C5;">
              <h2>NAME</h2>
          </div>
          <div class="col-md-3"style="display: flex;
          align-items: center;
          justify-content: center;
          border-right: 2px solid #C5C5C5;">
              <h2>BRANCH</h2>
          </div>
          <div class="col-md-3" style="display: flex;
          align-items: center;
          justify-content: center;
          border-right: 2px solid #C5C5C5;">
              <h2>TYPE</h2>
          </div>
      </div>  */}
    <div className="row  form-row">
      <table className="table">
        <thead>
          <tr style={{fontSize: '2rem', textAlign: 'center'}}>
            <th style={{borderRight: '2px solid #C5C5C5'}}>URN</th>
            <th style={{borderRight: '2px solid #C5C5C5'}}>NAME</th>
            <th style={{borderRight: '2px solid #C5C5C5'}}>BRANCH</th>
            <th style={{borderRight: '2px solid #C5C5C5'}}>TYPE</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><span className="urn">2121063</span></td>
            <td className="a"><span className="name">Ayush Singh</span></td>
            <td className="b"><span className="branch">IT</span></td>
            <td className="c"><span className="type">participate</span></td>
          </tr>
          <tr>
            <td><span className="urn">6536767</span></td>
            <td className="p"><span className="name">Tushar</span></td>
            <td className="q"><span className="branch">CSE</span></td>
            <td className="r"><span className="type">Winner</span></td>
          </tr>
          <tr>
            <td><span className="urn">76526352</span></td>
            <td className="u"><span className="name">Ansulpal</span></td>
            <td className="v"><span className="branch">ECE</span></td>
            <td className="w"><span className="type">Organiser</span></td>
          </tr>
        </tbody>
      </table>
    </div>
    {/* Row 7: Create and Reset Buttons */}
  </div>
</div>

  {/* ACTIVATE BUTTON */}
  <div className="row mt-5">
    <div className="col-7 " style={{color: 'black', fontSize: '2rem', fontWeight: 600, display: 'flex', alignItems: 'center', paddingLeft: '7rem'}}>
      Are you wanwt to Lock and export the Attendence?
    </div>
    <div className="col-5  " style={{display: 'flex', alignItems: 'center'}}>
      <div className="col-md-4 btn-container">
        <button className="btn btn-primary button" style={{backgroundColor: '#CA221B', width: '8rem'}}>YES</button>
      </div>
      <div className="col-md-4 btn-container">
        <button className="btn btn-secondary button" style={{width: '8REM', backgroundColor: '#CA221B'}}>NO</button>
      </div>
    </div>
  </div>
  
</div>

   </Layoutso>
  )
}

export default Attendence;