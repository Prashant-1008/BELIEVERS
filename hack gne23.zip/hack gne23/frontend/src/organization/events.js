import React, { useState,useEffect } from 'react';
import Layoutso from '../Layout/Layoutso';
import { Link, } from 'react-router-dom';
import axios from "axios";
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast'
const Events = () => {

  const [eventName,setEventName] = useState("")
  const [email,setEmail] = useState("")
  const [societyName,setSocietyName] = useState("")
  const [eventMode, setEventMode] = useState("");
  const [phoneNumber,setPhoneNumber] = useState("")
  const [startTime,setStartTime] = useState("")
  const [vanue,setVanue] = useState("")
  const [date,setDate] = useState("")
  const [deadlineTime,setDeadlineTime] = useState("")
  const [deadlineDate,setDeadlineDate] = useState("")
  const [eventDiscription,setEventDiscription] = useState("")
  const [whatsappLink,setWhatsappLink] = useState("")
  const navigate = useNavigate()

  const [userData, setUserData] = useState([]);

  const handleSubmit = async (e) =>{
      e.preventDefault();
      try {
          const res = await axios.post(`${process.env.REACT_APP_API}/api/v1/auth/events`,
          {eventName,  societyName, eventMode, phoneNumber,startTime , vanue, date,whatsappLink,deadlineTime,eventDiscription,deadlineDate}
          );
          if (res && res.data.success){
              toast.success(res.data.message)
              setTimeout(()=> {
                navigate('/');
               }, 2000);
          }else{
              toast.error(res.data.message)
          }
      } catch (error) {
          console.log(error)
          toast.error("Something went wrong");

          
      }
  };
  console.log(process.env.REACT_APP_API);

  const [showPassword, setShowPassword] = useState(false);

  const handleTogglePassword = () => {
      setShowPassword(!showPassword);
  };
    const [isEventListVisible, setIsEventListVisible] = useState(true);
    const [isCreateEventVisible, setIsCreateEventVisible] = useState(false);
  
    const showEventList = () => {
        setIsEventListVisible(true);
        setIsCreateEventVisible(false);
    };
  
    const showCreateEvent = () => {
        setIsEventListVisible(false);
      setIsCreateEventVisible(true);
    };

    // datat fecth
    useEffect(() => {
      const apiUrl = 'http://localhost:4000/api/v1/auth/';

      axios.get(apiUrl)
          .then(response => {
              const responseData = response.data;
              setUserData(responseData); // Store the data in the state
              
          })
          .catch(error => {
              console.error('Error:', error);
              console.error('Error:', error);
          });
  }, []);
//     console.log(userData);
  
const Data = userData.users;
  return (
    <Layoutso title={'Events'}>
<div className="container-fluid">
      <div className="row tab-style">
        <div className="col-1 p-0"></div>
        
        <div className={`col-5 p-0 ${isEventListVisible ? 'active-tab' : ''}`} onClick={showEventList}>
          <div className="tab-list">CREATED EVENTS LIST</div>
        </div>
        <div className={`col-5 justify-content-center p-0 ${isCreateEventVisible ? 'active-tab' : ''}`} onClick={showCreateEvent}>
          <div className="tab-list">CREATE EVENT</div>
          </div>
        <div className="col-1 p-0"></div>
      </div>

      {isEventListVisible && (<>
      
        <div className="container card-custom-container mb-5">
  <div className="row">
    <div className="col-2 custom-logo">
      <i className="fas fa-circle fa-10x" />
    </div>
    <div className="col-8">
      <div className="row">
        <div className="col-12 custom-text">
          Event Name: <span className="custom-data">csi </span>
        </div>
      </div>
      <div className="row">
        <div className="col-6 custom-text">
          Event Mode: <span className="custom-data">onlinee</span>
        </div>
        <div className="col-6 custom-text">
          Event Vanue: <span className="custom-data">auditorium</span>
        </div>
      </div>
      <div className="row">
        <div className="col-6 custom-text">
          Event Date: <span className="custom-data">31/01/2023</span>
        </div>
        <div className="col-6 custom-text">
          Event Start Time: <span className="custom-data">02:00:00</span>
        </div>
      </div>
      <div className="row">
        <div className="col-6 custom-text">
          Deadline Date: <span className="custom-data">21/7/2023</span>
        </div>
        <div className="col-6 custom-text">
          Deadline Time: <span className="custom-data">12:00:00</span>
        </div>
      </div>
      <div className="row">
        <div className="col-12 custom-text">
          Whatsapp Link: <span className="custom-data" style={{color: 'blue'}}>link of Whatsapp</span>
        </div>
      </div>
    </div>
    <div className="col-2 ">
      <div className="row">
        <div className="col-12  ">
          <button className="btn btn-secondary button" style={{backgroundColor: '#CA221B', marginTop: '4rem', marginBottom: '1rem', width: '14rem'}}>KNOW MORE</button>
        </div>
      </div>
      <div className="row">
        <div className="col-6">
          <button className="btn custom-button">
            <i className="fas fa-pencil-alt" style={{color: 'white', fontSize: '2rem'}} />
          </button>
        </div>
        <div className="col-6">
          <Link to="/u-home"><button className="btn custom-button" >
            <i className="fas fa-trash" style={{color: 'white', fontSize: '2rem'}} />
          </button></Link>
        </div>
      </div>
    </div>
  </div>
</div>

      {/* card2 */}
      <div className="container card-custom-container ">
  <div className="row">
    <div className="col-2 custom-logo">
      <i className="fas fa-circle fa-10x" />
    </div>
    <div className="col-8">
      <div className="row">
        <div className="col-12 custom-text">
          Event Name: <span className="custom-data">hacking</span>
        </div>
      </div>
      <div className="row">
        <div className="col-6 custom-text">
          Event Mode: <span className="custom-data">offline</span>
        </div>
        <div className="col-6 custom-text">
          Event Vanue: <span className="custom-data">auditorium</span>
        </div>
      </div>
      <div className="row">
        <div className="col-6 custom-text">
          Event Date: <span className="custom-data">21/2/2023</span>
        </div>
        <div className="col-6 custom-text">
          Event Start Time: <span className="custom-data">12:00:00</span>
        </div>
      </div>
      <div className="row">
        <div className="col-6 custom-text">
          Deadline Date: <span className="custom-data">21/2/2023</span>
        </div>
        <div className="col-6 custom-text">
          Deadline Time: <span className="custom-data">12:00:00</span>
        </div>
      </div>
      <div className="row">
        <div className="col-12 custom-text">
          Whatsapp Link: <span className="custom-data" style={{color: 'blue'}}>link of Whatsapp</span>
        </div>
      </div>
    </div>
    <div className="col-2 ">
      <div className="row">
        <div className="col-12  ">
          <button className="btn btn-secondary button" style={{backgroundColor: '#CA221B', marginTop: '4rem', marginBottom: '1rem', width: '14rem'}}>KNOW MORE</button>
        </div>
      </div>
      <div className="row">
        <div className="col-6">
          <button className="btn custom-button">
            <i className="fas fa-pencil-alt" style={{color: 'white', fontSize: '2rem'}} />
          </button>
        </div>
        <div className="col-6">
          <button className="btn custom-button">
            <i className="fas fa-trash" style={{color: 'white', fontSize: '2rem'}} />
          </button>
        </div>
      </div>
    </div>
  </div>
</div>
       
     </>
      )}

      {isCreateEventVisible && (
           <form onSubmit={handleSubmit} >
          <div className="container-fluid" style={{display: 'flex', justifyContent: 'space-around'}}>
  <div className="container-md-sm form-cont-style">
    {/* Row 1: Heading */}
    <div className="row ">
      <div className="col-12 form-heading">
        CREATE EVENT
      </div>
    </div>
    {/* Row 2: Society Name and Society Head (In One Line) */}
    <div className="row form-row-m form-row">
      <div className="col-md-6">
        <label className="form-label" htmlFor="enentname">Event Name</label>
        <input type="text" className="form-control input-box" id="entername" placeholder="Enter Event Name" value={eventName} 
        onChange={(e) => setEventName(e.target.value)}/>
      </div>
      <div className="col-md-6">
        <label className="form-label" htmlFor="societyname">Society Name</label>
        <input type="text" className="form-control input-box" id="societyname" placeholder="Enter Society Name"value={societyName} 
        onChange={(e) => setSocietyName(e.target.value)} />
      </div>
    </div>
    {/* Row 3: Society Convener and Contact (In One Line) */}
    <div className="row form-row-m form-row">
      <div className="col-md-6">
        <label className="form-label" htmlFor="mode">Event Mode</label>
        <input type="text" className="form-control input-box" id="mode" placeholder="Choose Mode"value={eventMode} 
        onChange={(e) => setEventMode(e.target.value)} />
      </div>
      <div className="col-md-6">
        <label className="form-label" htmlFor="Vanue">Venue</label>
        <input type="text" className="form-control input-box" id="Venue" placeholder="Enter Vanue" value={vanue} 
        onChange={(e) => setVanue(e.target.value)} />
      </div>
    </div>
    {/* Row 4: Email and Logo (In One Line) */}
    <div className="row form-row-m form-row">
      <div className="col-md-6">
        <label className="form-label" htmlFor="stime">Start Time</label>
        <input type="time" className="form-control input-box" id="stime" placeholder value={startTime} 
        onChange={(e) => setStartTime(e.target.value)}/>
      </div>
      <div className="col-md-6">
        <label className="form-label" htmlFor="date">Date</label>
        <input type="date" className="form-control input-box" id="date" placeholder="Enter date"
        value={date} 
        onChange={(e) => setDate(e.target.value)} />
      </div>
    </div>
    {/* Row 4.2: Email and Logo (In One Line) */}
    <div className="row form-row-m form-row">
      <div className="col-md-6">
        <label className="form-label" htmlFor="link">Whatsapp Link</label>
        <input type="text" className="form-control input-box " id="link" placeholder="Enter Whatsapp link"
        value={whatsappLink} 
        onChange={(e) => setWhatsappLink(e.target.value)} />
      </div>
      <div className="col-md-6">
        <label className="form-label" htmlFor="link">Contact</label>
        <input type="number" className="form-control input-box " id="link" placeholder="Enter Number" 
        value={phoneNumber} 
        onChange={(e) => setPhoneNumber(e.target.value)}/>
      </div>
    </div>
    {/* Row 5: Society Banner */}
    <div className="row form-row-m form-row">
      <div className="col-md-6">
        <label className="form-label" htmlFor="ddate">Deadline Date</label>
        <input type="date" className="form-control input-box " id="ddate" placeholder="Enter Deadline Date"
        value={deadlineDate} 
        onChange={(e) => setDeadlineDate(e.target.value)} />
      </div>
      <div className="col-md-6">
        <label className="form-label" htmlFor="dtime">Deadline Time</label>
        <input type="time" className="form-control input-box  " id="dtime" placeholder="Choose Banner" 
        value={deadlineTime} 
        onChange={(e) => setDeadlineTime(e.target.value)}/>
      </div>
    </div>
    {/* Row 5: Society Banner */}
    <div className="row form-row-m form-row">
      <div className="col-md-6">
        <label className="form-label" htmlFor="banner">Upload Banner</label>
        <input type="file" className="form-control-file chooseinput-box " id="banner" placeholder="Upload Banner" />
      </div>
    </div>
    <div className="row form-row-m form-row">
      <div className="col-md-12 preview">
        <label className="form-label" htmlFor="banner">Event Description</label>
        <div / > 
        <textarea className="preview-container" style={{height: 150, border: '1px solid #CA221B', borderRadius: 10}} rows={10} cols={110}  value={eventDiscription} 
        onChange={(e) => setEventDiscription(e.target.value)}/>
      </div>
    </div>
    {/* Row 7: Create and Reset Buttons */}
    <div className="row form-row-m">
      <div className="col-2" />
      <div className="col-md-4 btn-container">
        <button className="btn btn-primary button" style={{backgroundColor: '#CA221B'}}>CREATE SOCIETY</button>
      </div>
      <div className="col-md-4 btn-container">
        <button className="btn btn-secondary button" style={{backgroundColor: '#CA221B'}}>RESET</button>
      </div>
      <div className="col-2" />
    </div>
  </div>
</div>

</form>
      )}
    </div>
    </Layoutso>
    
  )
}

export default Events;