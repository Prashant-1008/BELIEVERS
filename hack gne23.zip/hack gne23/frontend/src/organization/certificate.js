import React, { useState } from 'react';
import Layoutso from '../Layout/Layoutso';
import { Link } from 'react-router-dom';

const Certificate = () => {
  
  
const [isEventListVisible, setIsEventListVisible] = useState(true);
    const [isCreateEventVisible, setIsCreateEventVisible] = useState(false);
  
    const showEventList = () => {
        setIsEventListVisible(true);
        setIsCreateEventVisible(false);
    };
  
    const showCreateEvent = () => {
        setIsEventListVisible(false);
      setIsCreateEventVisible(true);
    };
  return (
    <Layoutso title={"Certificate Generation"}>
<div className="container-fluid">
      <div className="row tab-style">
        <div className="col-1 p-0"></div>
        
        <div className={`col-5 p-0 ${isEventListVisible ? 'active-tab' : ''}`} onClick={showEventList}>
          <div className="tab-list">CHANGE CERTIFICATE fORMET UPDATE</div>
        </div>
        <div className={`col-5 justify-content-center p-0 ${isCreateEventVisible ? 'active-tab' : ''}`} onClick={showCreateEvent}>
          <div className="tab-list">GENERATE CERTIFICATE</div>
          </div>
        <div className="col-1 p-0"></div>
      </div>

      {isEventListVisible && (<>
      
      <div>
  {/* choose box */}
  <div className="container mt-4">
    <div className="row">
      <div className="col-1" />
      <div className="col-4">
        <p className="template-text">Choose Template :</p>
      </div>
      <div className="col-6">
        {/* <button type="button" class="custom-button custom-hover">Choose Template</button> */}
        <input type="file" id="file-input" name="file-input" />
        <label id="file-input-label" htmlFor="file-input">Choose Template</label>  
      </div>
      <div className="col-1" />
    </div>
  </div>
  {/* FORM-START */}
  <div className="container-fluid" style={{display: 'flex', justifyContent: 'space-around'}}>
    <div className="row form-row-m form-row">
      <div className="col-md-12 preview">
        <div className="preview-container" style={{width: '87vw', height: '70vh', border: '1px solid #CA221B', borderRadius: 10}} /> 
      </div>
    </div>
  </div>
  <div className="container-fluid">
    <div className="container-md-sm ">
      {/* Row 7: Create and Reset Buttons */}
      <div className="row form-row-m">
        <div className="col-4" />
        <div className="col-md-4 btn-container">
          <button className="btn btn-primary button" style={{backgroundColor: '#CA221B'}}>UPDATE</button>
        </div>
        <div className="col-4" />
      </div>
    </div>
  </div>
</div>

       
     </>
      )}

      {isCreateEventVisible && (
           
          
          <div>
  {/* Choose event */}
  <div className="container mt-4">
    <div className="row">
      <div className="col-1" />
      {/* <div className="col-4">
        <p className="event-text">Choose Event </p>
      </div> */}
      <div className="col-6">
        {/* <div className="dropdown">
          <button className="btn custom-dropdown dropdown-toggle" type="button" id="eventDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Choose Event
          </button>
          <div className="dropdown-menu" aria-labelledby="eventDropdown">
            <a className="dropdown-item" href="#" data-value="workshop">workshop</a>
            <a className="dropdown-item" href="#" data-value="competition">competition</a>
            <a className="dropdown-item" href="#" data-value="expert-talk">Expert talk</a>
          </div>
        </div> */}
      </div>
      <div className="col-1" />
    </div>
  </div>
  {/* FORM-START */}
   <div className="container-fluid" style={{display: 'flex', justifyContent: 'space-around'}}>
    <div className="row form-row-m form-row">
      <div className="col-md-12 preview">
        {/* <div className="preview-container" style={{width: '87vw', height: '70vh', border: '1px solid #CA221B', borderRadius: 10}} />  */}
      </div>
    </div>
  </div> 


{/* <div className="input-form">
  
 <span> Enter Name</span> <input required type="text" placeholder="NAME" id="name" minLength={3} maxLength={20} /><br/>
 <span> Enter Society</span> <input required type="text" placeholder="SOCIETY NAME" id="society" minLength={3} maxLength={16} /><br/>
 <span> Enter Society</span> <input required type="text" placeholder="EVENT NAME" id="event" minLength={3} maxLength={16} /><br/>
 <span> Event Date</span> <input required type="date" placeholder="DATE" id="date" /><br/>
     <button id="submitBtn"  style={{backgroundColor: '#CA221B'}}>Get Certificate</button>
</div> */}


  {/* CERTIFICATE VERIFICATION */}
  <div className="container-fluid">
    <div className="container-md-sm ">
      {/* Row 7: Create and Reset Buttons */}
      <div className="row form-row-m">
        <div className="col-4" />
        <div className="col-md-4 btn-container">
          <Link to ="https://jaipurgali.com/"> <button className="btn btn-primary button" style={{backgroundColor: '#CA221B'}}>GENERATE CERTIFICATE</button> </Link>
        </div>
        <div className="col-4" />
      </div>
    </div>
  </div>
</div>

     
      )}
    </div>
  </Layoutso>
  )
}

export default Certificate;