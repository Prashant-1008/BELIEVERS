import React from 'react'
import Headerso from './headerso.js';
import Footer from './footer.js';
import  {Toaster}   from 'react-hot-toast';
import{Helmet} from "react-helmet";

const Layoutso = ({children,title}) => {
  return (
    <div>
      <Helmet>
  <meta charSet='utf8'/>
  <title>{title}</title>
</Helmet>
        <Headerso/>
        <main style={{minHeight:"100vh"}}>
        <Toaster
        toastOptions={{
          // Define default options
          className: '',
          position: 'top-right',
          duration: 5000,
          style: {
            background: '#fff',
            color: '#363636',
          },
      
          // Default options for specific types
          success: {
            duration: 5000,
            theme: {
              primary: 'green',
              secondary: 'black',
            },
          },
        }}
        /> 
        {children}
        </main>
        <Footer/>
    </div>
  );
};

export default Layoutso;