import React from 'react'
import { Link } from 'react-router-dom'
import '../Layout/nav.css'
const Header = () => {
  return (
    <>
    <div  className='container-fluide'>
    <img  src="logo.png" className="img-fluid header" alt="logo" />

    <div>
    <nav className="navbar navbar-expand-md " style={{height: '6rem', backgroundColor: '#CA221B'}}>
  <div className="container-fluid">
    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent">
      <span className="navbar-toggler-icon" />
    </button>
    <div className="collapse navbar-collapse" id="navbarSupportedContent">
      <ul className="navbar-nav me-auto mb-2 mb-lg-0">
        <li className="nav-item">
          <Link className="nav-link " to="/">Home</Link>
        </li>
      </ul>
      {/* LOGOUT-OUTLINE */}
       <div>
       <Link to="/"> <button className="btn btn-outline-light" type="submit" id="logout">LOGOUT</button></Link>
      </div> 
    </div>
  </div>
</nav>

    </div>
    </div>
    </>
    
    
  )
}

export default Header;