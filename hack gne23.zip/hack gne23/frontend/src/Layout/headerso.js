import React from 'react'
import { NavLink ,Link } from 'react-router-dom'
import '../Layout/nav.css'
const Headerso = () => {
  return (
    <>
    <div  className='container-fluide'>
    <img  src="logo.png" className="img-fluid header" alt="logo" />

    <div>
    <nav className="navbar navbar-expand-md " style={{height: '6rem', backgroundColor: '#CA221B'}}>
  <div className="container-fluid">
    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent">
      <span className="navbar-toggler-icon" />
    </button>
    <div className="collapse navbar-collapse" id="navbarSupportedContent">
      <ul className="navbar-nav me-auto mb-2 mb-lg-0">
        <li className="nav-item">
          <NavLink className="nav-link active" to="/s-home">Home</NavLink>
        </li>
        <li className="nav-item">
          <NavLink className="nav-link active " to="/s-events">Events</NavLink>
        </li>
        <li className="nav-item">
          <NavLink className="nav-link active" to="/s-registration">Registrations</NavLink>
        </li>
        <li className="nav-item">
          <NavLink className="nav-link active" to="/s-attendence">Attendence</NavLink>
        </li>
        <li className="nav-item">
          <NavLink className="nav-link active" to="/s-certificate">Certificate</NavLink>
        </li>
       
      </ul>
      {/* LOGOUT-OUTLINE */}
       <div>
       <Link to="/"> <button className="btn btn-outline-light" type="submit" id="logout">LOGOUT</button></Link>
      </div> 
    </div>
  </div>
</nav>

    </div>
    </div>
    </>
    
    
  )
}

export default Headerso;