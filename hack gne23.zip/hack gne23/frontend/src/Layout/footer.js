import React from 'react'

const Footer = () => {
  return (
    <div className="footer mt-4">All Right Reserved © GNDEC-2023</div>
  )
}

export default Footer;