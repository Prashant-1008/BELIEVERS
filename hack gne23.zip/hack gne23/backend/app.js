const express = require("express");
const app = express();
const ErrorHandler = require("./middleware/error");

app.use(express.json())
// route import
const event = require("./routes/eventRoute");

app.use("/api/v1",event);

// it's for errorHandeling
app.use(ErrorHandler);

module.exports = app;