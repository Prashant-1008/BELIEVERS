const express = require("express");
const { getAllEvent, createEvent  } = require("../controller/eventController");
const router= express.Router();

router.route("/event").get(getAllEvent);
router.route("/event/new").post(createEvent);

module.exports = router