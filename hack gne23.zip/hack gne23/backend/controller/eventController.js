const Event = require("../models/EventModel");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");


// Ceate event
exports.createEvent = catchAsyncErrors( async(req,res,next)=>{
    const event = await Event.create(req.body);
    res.status(201).json({
        success:true,
        event
    })
});
//get all event

exports.getAllEvent = catchAsyncErrors(async(req,res)=>{
    
    const events = await Event.find();

    res.status(200).json({
        success:true,
        events
    })
});