const mongoose = require("mongoose");

const eventSchema = new mongoose.Schema({
    eventName:{
        type:String,
        required:[true, "Please enter Event name"],
        trim: true,
        maxLength:[20, "Event name not exceed than 20 characters"]
    },
    eventDescription:{
        type:String,
        required:[true, "Please enter Event Discription"],
        trim: true,
        maxLength:[200, "Event discription not exceed than 200 characters"]
    },
    eventOrganizer:{
        type:String,
        required:[true, "Please enter Event Organizer name"],
        trim: true,
        maxLength:[20, "Event  Organizer name not exceed than 20 characters"]
    },
    email: {
        type: String,
        required: [true, "Please enter your email"],
        
      },
      phoneNumber: {
        type: String,
        required: true,
        
      },
      eventDate:{
        type: String,
        required: true,
        
      },
      eventTime:{
        type: String,
        required: true,
        
      },
      eventVenue:{
        type: String,
        required: true,
        
      },
      eventBanner:[
        {
            public_id:{
                type:String,
                required:true
            },
            url:{
                type:String,
                requrired:true
            }
        }
      ],
    
    
  createAt:{
      type:Date,
      default: Date.now()
  }
})

module.exports = mongoose.model("Event",eventSchema);