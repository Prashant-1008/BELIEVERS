import { comparePassword, hashPassword } from "../helpers/authHelper.js";
import userModel from "../models/userModel.js";
import eventModel from "../models/eventModel.js";
import JWT from "jsonwebtoken";

export const registerController = async (req, res) => {
  try {
    const { name, email, password, phoneNumber, branch,urn,crn,year ,conformpassword } = req.body;
    if (name.length < 3 || name.length > 12) {
      return res.send({message:"Name should be between 3 and 12 characters."});
      
  }
  
    if (!email) {
      return res.send({ message: " Email is required" });
    }
    
    const passwordRegex = /^(?=.*[a-zA-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
        if (!passwordRegex.test(password)) {
          return res.send({message:"Password should be at least 8 characters long and contain at least one letter, one digit, and one special character."});
           
        }
    if (phoneNumber.length !== 10) {
      return res.send({message:"Phone number should be exactly 10 digits."});
      
  }

    
  
    
    // check user
    const exisitingUser = await userModel.findOne({ email });
    //existing user
    if (exisitingUser) {
      return res.status(200).send({
        success: false,
        message: "Already Register please login",
      });
    }
    //register user
    const hashedPassword = await hashPassword(password);
    //save
    const user = await new userModel({
      name,
      email,
      phoneNumber,
      branch,
      crn,
      urn,
      password: hashedPassword,
      year,
      
    }).save();

    res.status(201).send({
      success: true,
      message: "User Register Successfully",
      user,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Error in Registertion",
      error,
    });
  }
};
//asigen dutie
export const AsignDutyController = async (req, res) => {
  try {
    const { lati,longi, address, time,startingtime,endingtime } = req.body;
    if (!lati) {
      return res.send({ message: "Latitude is required" });
    }
    if (!longi) {
      return res.send({ message: " Longitude is required" });
    }
    
    if (!address) {
      return res.send({ message: "Address is required" });
    }
    if (!time) {
      return res.send({ message: "Time no. is required" });
    }
    if (!startingtime) {
      return res.send({ message: "Starting time is required" });
    }
    if (!endingtime) {
      return res.send({ message: "Endding time is required" });
    }
    // check user
    // const exisitingUser = await userModel.findOne({ email });
    // //existing user
    // if (exisitingUser) {
    //   return res.status(200).send({
    //     success: false,
    //     message: "Already Register please login",
    //   });
    // }
    // //register user
    // const hashedPassword = await hashPassword(password);
    //save
    const user = await new userModel({
      lati,
      longi,
      address,
      time,
      startingtime,
      endingtime,
      
      
    }).save();

    res.status(201).send({
      success: true,
      message: "Assign Duty Successfully",
      user,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Assign DutyError in ",
      error,
    });
  }
};
// post login
export const loginController = async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(404).send({
        success: false,
        message: "Error in login",
      });
    }
    //check user
    const user = await userModel.findOne({ email });
    if (!user) {
      return res.status(404).send({
        success: false,
        message: "Email is not resgisterd",
      });
    }
    const match = await comparePassword(password, user.password);
    if (!match) {
      return res.status(200).send({
        success: false,
        message: "Invalid Password",
      });
    }

    //token
    const token = await JWT.sign({ _id: user._id }, process.env.JWT_SECRET, {
      expiresIn: "7d",
    });
    res.status(200).send({
      success: true,
      message: "login successfully",
      user: {
        name: user.name,
        email: user.email,
        phone: user.phone,
        address: user.address,
        role: user.role,
      },
      token,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Error in login",
      error,
    });
  }
};


//forgot password
export const forgotPasswordController = async (req, res) => {
  try {
    const { email, answer, newPassword } = req.body;
    if (!email) {
      res.status(400).send({ message: "Email is required" });
    }
    if (!answer) {
      res.status(400).send({ message: "answer is required" });
    }
    if (!newPassword) {
      res.status(400).send({ message: "New Password  is required" });
    }
    //check
    const user = await userModel.findOne({ email, answer });
    //validation
    if (!user) {
      return res.status(404).send({
        success: false,
        message: "Wrong Email and answer",
      });
    }
    const hashed = await hashPassword(newPassword);
    await userModel.findByIdAndUpdate(user._id, { password: hashed });
    res.status(200).send({
      success: true,
      message: "Password Reset Successfully",
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Something went wrong",
      error,
    });
  }
};
//test controller
export const testController = (req, res) => {
  try {
    res.send("Protected Routes");
  } catch (error) {
    console.log(error);
    res.send({ error });
  }
};
 //update prfole
export const updateProfileController = async (req, res) => {
  try {
    const { Latitude,Longitude} = req.body;
    
    const user = await userModel.findById(req.user._id);
    
    const updatedUser = await userModel.findByIdAndUpdate(
      req.user._id,
      {
        Latitude: Latitude || user.Latitude,
        
        Longitude: Longitude || user.Longitude,
        
      },
      { new: true }
    );
    res.status(200).send({
      success: true,
      message: "Profile Updated SUccessfully",
      updatedUser,
    });
  } catch (error) {
    console.log(error);
    res.status(400).send({
      success: false,
      message: "Error WHile Update profile",
      error,
    });
  }
};

export const updateProfile = async(req,res,next) =>{
  const newUserData = {
    Latitude: req.body.Latitude,
    Longitude: req.body.Longitude,
  };



const user = await user.findByIdAndUpdate(req.user.id, newUserData, {
  new: true,
  runValidator: true,
  useFindAndModify: false,
});

res.status(200).json({
  success: true,
});
};
//assign duty
export const assignDuty = async (req, res) => {
  try {
    const { lati,longi,date,time,address,startingtime,endingtime} = req.body;
    
    const user = await userModel.findByIdAndUdate(req.user._id);
    
    const updatedUser = await userModel.findByIdAndUpdate(
      req.user._id,
      {
        lati: lati || user.lati,
        
        longi: longi || user.longi,
        date: date || user.date,
        time: time || user.time,
        address:address || user.address,
        startingtime:startingtime || user.startingtime,
        endingtime:endingtime ||user.endingtime

        
      },
      { new: true }
    );
    res.status(200).send({
      success: true,
      message: "Profile Updated SUccessfully",
      updatedUser,
    });
  } catch (error) {
    console.log(error);
    res.status(400).send({
      success: false,
      message: "Error WHile Update profile",
      error,
    });
  }
};
//get all products
export const getuserController = async (req, res) => {
  try {
    const users = await userModel
      .find({})
      
      .limit(12)
      .sort({ createdAt: -1 });
    res.status(200).send({
      success: true,
      counTotal: users.length,
      message: "ALlUsers ",
      users,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Erorr in users",
      error: error.message,
    });
  }
};
// get single user
export const getSingleUeserController = async (req, res) => {
  try {
    const user = await userModelModel
      .findOne({ slug: req.params.slug })
      
      
    res.status(200).send({
      success: true,
      message: "Single user Fetched",
      user,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Eror while getitng single user",
      error,
    });
  }
};

// event

// events

export const eventController = async (req, res) => {
  try {
    const { eventName,  societyName, eventMode, phoneNumber,startTime , vanue, date,whatsappLink,deadlineTime,eventDiscription,deadlineDate } = req.body;
    
    
    
    //save
    const user = await new eventModel({
      eventName,  societyName, eventMode, phoneNumber,startTime , vanue, date,whatsappLink,deadlineTime,eventDiscription,deadlineDate,
    }).save();

    res.status(201).send({
      success: true,
      message: "Event Register Successfully",
      user,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Error in Event Register",
      error,
    });
  }
};

// show all evnts
 //get all products
 export const geteventController = async (req, res) => {
  try {
    const users = await eventModel
      .find({})
      
      .limit(12)
      .sort({ createdAt: -1 });
    res.status(200).send({
      success: true,
      counTotal: users.length,
      message: "ALlUsers ",
      users,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Erorr in users",
      error: error.message,
    });
  }
};