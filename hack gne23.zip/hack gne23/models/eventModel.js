import mongoose from "mongoose";
const eventSchema = new mongoose.Schema(
  {
    eventName: {
      type: String,
      //required: true,
      trim: true,
     
    },
    societyName: {
      type: String,
      //required: true,
      unique: true,
    },
    eventMode: {
      type: String,
      //required: true,
    },
    phoneNumber: {
      type: String,
      //required: true,
      
    },
    vanue: {
      type: String,
      //required: true,
      
    },
    startTime: {
      type: String,
      //required: true,
      
    },
    date:{
      type:String,
    },
    whatsappLink: {
      type: String,
      //required: true,
      
    },
    deadlineDate:{
        type:String,
        //required: true,
      },
    deadlineTime:{
        type:String,
      },
      eventDiscription:{
        type:String,

      },
    
    
    role: {
      type: Number,
      default: 0,
    },
  },
  { timestamps: true }
);

export default mongoose.model("events", eventSchema);