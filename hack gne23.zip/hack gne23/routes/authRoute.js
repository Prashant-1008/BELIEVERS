import express from "express";
import {
  registerController,
  loginController,
  testController,
  forgotPasswordController,
getuserController,
getSingleUeserController,
updateProfile,
  eventController,
  geteventController
} from "../controllers/authController.js";
import { isAdmin, requireSignIn } from "../middlewares/authMiddleware.js";

//router object
const router = express.Router();
//routing
//register , method post
router.post("/register", registerController);
router.post("/events", eventController);
router.post("/allevents", geteventController);

//login, method post
router.post("/login", loginController);

//forget password
router.post("/forgot-password", forgotPasswordController);

//test route
router.get("/test", requireSignIn, isAdmin, testController);
//protected user route
router.get("/user-auth", requireSignIn, (req, res) => {
  res.status(200).send({ ok: true });
});
//protected admin route
//update profile
router.put("/profile",updateProfile);

//get products
router.get("/get-user", getuserController);
//single user
router.get("/get-user/:id", getSingleUeserController);
router.get("/admin-auth", requireSignIn, (req, res) => {
  res.status(200).send({ ok: true });
});

export default router;
