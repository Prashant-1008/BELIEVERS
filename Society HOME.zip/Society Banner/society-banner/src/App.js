import './App.css';
import bannerImage from './image/ban.png';
import societyBanner from './image/sb.png';
import personImage from './image/pic.png';


function App() {
  return (
    <div className="App">
      <div className='container'>
        <img src={bannerImage} alt=""/>
        <header>
          <nav>
            <ul>
              <li><a href="#">Home</a></li>
              <li><a href="#">Event</a></li>
              <li><a href="#">Certificate</a></li>
              <li><a href="#">Registrations</a></li>
              <li><a href="#">Attendance</a></li>
            </ul>
          </nav>
        </header>
        <div className='banner'>
          <img src={societyBanner} alt="" />
        </div>
        <div className='boxes'>
          <div className='box1'>
            <h4>
              SOCIETY DETAILS
            </h4>
            <img src={personImage} />
            <p>Society Name: <span>Computer Society Of India</span></p>
          </div>
          <div className='box2'>

          </div>
        </div>
        <footer>
        <p>GURU NANAK DEV ENGINEERING COLLEGE COPYRIGHT-2023</p>
    </footer>
      </div>

    </div>
  );
}

export default App;
